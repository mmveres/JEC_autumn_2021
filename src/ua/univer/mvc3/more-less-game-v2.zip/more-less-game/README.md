# More-less JAVA game
Code structure is based on MVC pattern.

It's a console game where you should guess an integer number in range from 0 to 100 inclusively. When you guess the target number you will get summury of your attempts (all values that you have entered and number of tries).
[Main java class](./src/main/java/com/game/Main.java)

### App localization
  * English
  * Russian
  * Ukrainian